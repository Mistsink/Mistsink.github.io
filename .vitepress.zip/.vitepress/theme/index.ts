import YzhTheme from "../../yzh-theme";
import DefaultTheme from 'vitepress/theme';

export default YzhTheme
// export default DefaultTheme