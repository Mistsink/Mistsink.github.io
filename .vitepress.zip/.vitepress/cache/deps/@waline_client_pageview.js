import "./chunk-T2T6Q22Z.js";

// node_modules/.pnpm/@waline+client@2.14.9/node_modules/@waline/client/dist/pageview.mjs
var e = "2.14.9";
var t = { "Content-Type": "application/json" };
var n = ({ serverURL: e2, lang: t2, paths: n2, signal: a2 }) => (({ serverURL: e3, lang: t3, paths: n3, type: a3, signal: r2 }) => fetch(`${e3}/article?path=${encodeURIComponent(n3.join(","))}&type=${encodeURIComponent(a3.join(","))}&lang=${t3}`, { signal: r2 }).then((e4) => e4.json()))({ serverURL: e2, lang: t2, paths: n2, type: ["time"], signal: a2 }).then((e3) => Array.isArray(e3) ? e3 : [e3]);
var a = (e2) => (({ serverURL: e3, lang: n2, path: a2, type: r2, action: o2 }) => fetch(`${e3}/article?lang=${n2}`, { method: "POST", headers: t, body: JSON.stringify({ path: a2, type: r2, action: o2 }) }).then((e4) => e4.json()))({ ...e2, type: "time", action: "inc" });
var r = (e2) => {
  const t2 = ((e3 = "") => e3.replace(/\/$/u, ""))(e2);
  return /^(https?:)?\/\//.test(t2) ? t2 : `https://${t2}`;
};
var o = (e2) => {
  "AbortError" !== e2.name && console.error(e2.message);
};
var l = (e2) => e2.dataset.path || e2.getAttribute("id");
var s = (e2, t2) => {
  t2.forEach((t3, n2) => {
    t3.innerText = e2[n2].toString();
  });
};
var i = ({ serverURL: e2, path: t2 = window.location.pathname, selector: i2 = ".waline-pageview-count", update: p = true, lang: c = navigator.language }) => {
  const h = new AbortController(), g = Array.from(document.querySelectorAll(i2)), y = (e3) => {
    const n2 = l(e3);
    return null !== n2 && t2 !== n2;
  }, d = (a2) => n({ serverURL: r(e2), paths: a2.map((e3) => l(e3) || t2), lang: c, signal: h.signal }).then((e3) => s(e3, a2)).catch(o);
  if (p) {
    const n2 = g.filter((e3) => !y(e3)), o2 = g.filter(y);
    a({ serverURL: r(e2), path: t2, lang: c }).then((e3) => s(new Array(n2.length).fill(e3), n2)), o2.length && d(o2);
  } else
    d(g);
  return h.abort.bind(h);
};
export {
  i as pageviewCount,
  e as version
};
//# sourceMappingURL=@waline_client_pageview.js.map
